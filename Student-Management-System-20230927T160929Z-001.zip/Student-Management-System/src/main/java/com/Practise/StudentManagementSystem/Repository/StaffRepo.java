package com.Practise.StudentManagementSystem.Repository;

import com.Practise.StudentManagementSystem.Model.Staff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StaffRepo extends JpaRepository<Staff,Integer> {
}
