package com.Practise.StudentManagementSystem.Controller;

import com.Practise.StudentManagementSystem.AccesControl.RoleAuthorization;
import com.Practise.StudentManagementSystem.Model.Staff;
import com.Practise.StudentManagementSystem.Repository.StaffRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.security.sasl.AuthenticationException;

@RestController
@RequestMapping("/api/staff")
public class StaffController {
    @Autowired
    private StaffRepo staffRepo;
    @PostMapping("/add")
    public void addOrUpdateStaff(@RequestBody Staff staff, @RequestHeader("Authorization") String token) throws Exception{
        if (RoleAuthorization.hasAccess(token, "Principal")) {
            staffRepo.save(staff); //save can also work as update
        }else if (RoleAuthorization.hasAccess(token, "HOD")) {
            staffRepo.save(staff);
        }else {
            throw new AuthenticationException("not Authorized");
        }
    }

    @DeleteMapping("/delete/{id}")
    public void deleteStaff (@PathVariable Integer id, @RequestHeader("Authorization") String token) throws Exception {
        Staff staff = staffRepo.findById(id).get();
        if (RoleAuthorization.hasAccess(token, "Principal")) {
            staffRepo.delete(staff);
        }else if (RoleAuthorization.hasAccess(token,"HOD")) {
            staffRepo.delete(staff);
        }else {
            throw new AuthenticationException("not authorized");
        }
    }
}
