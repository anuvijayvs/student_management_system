package com.Practise.StudentManagementSystem.AccesControl;

import com.Practise.StudentManagementSystem.Utilities.JwtUtil;
import io.jsonwebtoken.Claims;

public class RoleAuthorization {
    public static boolean hasAccess(String token, String requiredRole) {
        Claims claims = JwtUtil.parseToken(token);
        String userRole = claims.get("role", String.class);
        return userRole.equals(requiredRole);
    }
}