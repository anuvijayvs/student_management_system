package com.Practise.StudentManagementSystem.Repository;

import com.Practise.StudentManagementSystem.Model.Principal;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PrinciRepo extends JpaRepository<Principal,Integer> {
}
