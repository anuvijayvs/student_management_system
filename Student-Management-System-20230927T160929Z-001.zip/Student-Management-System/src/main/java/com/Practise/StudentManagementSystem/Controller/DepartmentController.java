package com.Practise.StudentManagementSystem.Controller;

import com.Practise.StudentManagementSystem.AccesControl.RoleAuthorization;
import com.Practise.StudentManagementSystem.Model.Department;
import com.Practise.StudentManagementSystem.Repository.DepartmentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.security.sasl.AuthenticationException;

@RestController
@RequestMapping("/api/departments")
public class DepartmentController {
    @Autowired
    private DepartmentRepo departmentRepo;
    @PostMapping("/add")
    public void addDepartment(@RequestBody Department department, @RequestHeader("Authorization") String token) throws Exception{
        if (RoleAuthorization.hasAccess(token, "Principal")) {
            departmentRepo.save(department);
        } else {
            throw new AuthenticationException("User not authorized");
        }
    }

    @DeleteMapping("/delete/{id}")
    public void deleteDepartment(@PathVariable Integer id, @RequestHeader("Authorization") String token) throws Exception{
        Department department = departmentRepo.findById(id).get();
        if (RoleAuthorization.hasAccess(token, "Principal")) {
            departmentRepo.delete(department);
        } else {
            throw new AuthenticationException("User not authorized");
        }
    }

}
