package com.Practise.StudentManagementSystem.Controller;

import com.Practise.StudentManagementSystem.AccesControl.RoleAuthorization;
import com.Practise.StudentManagementSystem.Model.Student;
import com.Practise.StudentManagementSystem.Repository.StudentRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.security.sasl.AuthenticationException;

@RestController
@RequestMapping("/api/student")
public class StudentController {
    @Autowired
    private StudentRepo studentRepo;
    @PostMapping("/add")
    public void addOrUpdateStudent (@RequestBody Student student, @RequestHeader("Authorization") String token) throws Exception {
        if (RoleAuthorization.hasAccess(token, "staff")) {
            studentRepo.save(student);
        }else if (RoleAuthorization.hasAccess(token, "principal")) {
            studentRepo.save(student);
        }else if(RoleAuthorization.hasAccess(token, "HOD")) {
            studentRepo.save(student);
        } else {
            throw new AuthenticationException("not authorized user");
        }
    }

    @DeleteMapping("/delete")
    public void deleteStudent (@PathVariable Integer id, @RequestHeader("Authorization") String token) throws Exception {
        Student student = studentRepo.findById(id).get();

        if (RoleAuthorization.hasAccess(token, "staff")) {
            studentRepo.delete(student);
        } else if (RoleAuthorization.hasAccess(token, "Principal")) {
            studentRepo.delete(student);
        }if (RoleAuthorization.hasAccess(token, "HOD")) {
            studentRepo.delete(student);
        }else {
            throw new AuthenticationException("not authorized user");
        }
    }
}
