package com.Practise.StudentManagementSystem.Repository;

import com.Practise.StudentManagementSystem.Model.HOD;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HODRepo extends JpaRepository<HOD,Integer> {
}
